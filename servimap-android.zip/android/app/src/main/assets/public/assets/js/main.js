// ServiMap Landing Page JavaScript

// Global variables
let deferredPrompt;
let isMenuOpen = false;

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializePWA();
    initializeNavigation();
    initializeScrollEffects();
    initializeModals();
});

// PWA Installation
function initializePWA() {
    // Listen for beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        console.log('PWA install prompt captured');
    });

    // Handle successful installation
    window.addEventListener('appinstalled', () => {
        console.log('PWA installed successfully');
        deferredPrompt = null;
        showNotification('¡ServiMap instalado correctamente!', 'success');
    });
}

// Navigation functions
function initializeNavigation() {
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offsetTop = target.offsetTop - 80; // Account for fixed navbar
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Navbar background on scroll
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        }
    });
}

// Mobile menu toggle
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const mobileBtn = document.querySelector('.mobile-menu-btn');
    
    isMenuOpen = !isMenuOpen;
    
    if (isMenuOpen) {
        navMenu.style.display = 'flex';
        navMenu.style.position = 'absolute';
        navMenu.style.top = '100%';
        navMenu.style.left = '0';
        navMenu.style.right = '0';
        navMenu.style.background = 'white';
        navMenu.style.flexDirection = 'column';
        navMenu.style.padding = '1rem';
        navMenu.style.boxShadow = '0 4px 6px -1px rgb(0 0 0 / 0.1)';
        navMenu.style.borderTop = '1px solid var(--border-color)';
        mobileBtn.classList.add('active');
    } else {
        navMenu.style.display = 'none';
        mobileBtn.classList.remove('active');
    }
}

// Scroll effects
function initializeScrollEffects() {
    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.service-card, .about-card, .testimonial-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Modal functions
function initializeModals() {
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

// Install prompt functions
function showInstallPrompt() {
    const modal = document.getElementById('installModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeInstallModal() {
    const modal = document.getElementById('installModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function installPWA() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the install prompt');
                showNotification('¡Instalando ServiMap...!', 'success');
            } else {
                console.log('User dismissed the install prompt');
            }
            deferredPrompt = null;
            closeInstallModal();
        });
    } else {
        // Fallback instructions
        showInstallInstructions();
    }
}

function showInstallInstructions() {
    const userAgent = navigator.userAgent.toLowerCase();
    let instructions = '';
    
    if (userAgent.includes('android')) {
        instructions = 'Para instalar ServiMap:\n1. Toca el menú (⋮) del navegador\n2. Selecciona "Instalar app" o "Agregar a pantalla de inicio"\n3. Confirma la instalación';
    } else if (userAgent.includes('iphone') || userAgent.includes('ipad')) {
        instructions = 'Para instalar ServiMap:\n1. Toca el botón de compartir (↗)\n2. Selecciona "Agregar a pantalla de inicio"\n3. Toca "Agregar"';
    } else {
        instructions = 'Para instalar ServiMap:\n1. Busca el ícono de instalación en la barra de direcciones\n2. Haz clic en "Instalar"\n3. Confirma la instalación';
    }
    
    alert(instructions);
    closeInstallModal();
}

function goToAppStores() {
    const userAgent = navigator.userAgent.toLowerCase();
    
    if (userAgent.includes('android')) {
        showNotification('Próximamente en Google Play Store', 'info');
        // window.open('https://play.google.com/store/apps/details?id=com.servimap.app', '_blank');
    } else if (userAgent.includes('iphone') || userAgent.includes('ipad')) {
        showNotification('Próximamente en App Store', 'info');
        // window.open('https://apps.apple.com/app/servimap/id123456789', '_blank');
    } else {
        showNotification('Las apps móviles están disponibles en dispositivos móviles', 'info');
    }
    
    closeInstallModal();
}

// Download functions
function downloadAndroid() {
    showNotification('Próximamente en Google Play Store', 'info');
    // In the future, redirect to Play Store
    // window.open('https://play.google.com/store/apps/details?id=com.servimap.app', '_blank');
}

function downloadiOS() {
    showNotification('Próximamente en App Store', 'info');
    // In the future, redirect to App Store
    // window.open('https://apps.apple.com/app/servimap/id123456789', '_blank');
}

// Utility functions
function scrollToServices() {
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
        const offsetTop = servicesSection.offsetTop - 80;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

function showWebAppInfo() {
    const modal = createInfoModal(
        'Web App de ServiMap',
        'ServiMap funciona perfectamente como una aplicación web progresiva (PWA). Puedes:\n\n• Usarla directamente desde tu navegador\n• Instalarla como app nativa\n• Recibir notificaciones push\n• Usarla offline\n\n¿Te gustaría instalar la PWA ahora?',
        [
            { text: 'Instalar PWA', action: installPWA, primary: true },
            { text: 'Usar en navegador', action: () => window.location.href = '#services' },
            { text: 'Cerrar', action: null }
        ]
    );
    document.body.appendChild(modal);
    modal.style.display = 'block';
}

// Legal functions
function showPrivacyPolicy() {
    const modal = createInfoModal(
        'Política de Privacidad',
        'En ServiMap, protegemos tu privacidad y datos personales:\n\n• Solo recopilamos información necesaria para el servicio\n• No vendemos datos a terceros\n• Usamos encriptación para proteger tu información\n• Puedes eliminar tu cuenta en cualquier momento\n• Cumplimos con GDPR y leyes locales de privacidad\n\nPara más detalles, contacta a nuestro equipo legal.',
        [{ text: 'Entendido', action: null }]
    );
    document.body.appendChild(modal);
    modal.style.display = 'block';
}

function showTermsOfService() {
    const modal = createInfoModal(
        'Términos de Servicio',
        'Al usar ServiMap, aceptas estos términos:\n\n• Usar el servicio de manera responsable\n• Proporcionar información veraz\n• Respetar a otros usuarios y proveedores\n• No usar la plataforma para actividades ilegales\n• ServiMap se reserva el derecho de suspender cuentas que violen estos términos\n\nNuestros términos completos están disponibles en el panel de administración.',
        [{ text: 'Acepto', action: null }]
    );
    document.body.appendChild(modal);
    modal.style.display = 'block';
}

function showCookiePolicy() {
    const modal = createInfoModal(
        'Política de Cookies',
        'ServiMap usa cookies para mejorar tu experiencia:\n\n• Cookies esenciales: Necesarias para el funcionamiento\n• Cookies de rendimiento: Para analizar el uso de la app\n• Cookies de funcionalidad: Para recordar tus preferencias\n• Cookies de publicidad: Para mostrar anuncios relevantes\n\nPuedes gestionar las cookies desde la configuración de tu navegador.',
        [{ text: 'Entendido', action: null }]
    );
    document.body.appendChild(modal);
    modal.style.display = 'block';
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${getNotificationIcon(type)}</span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10001;
        min-width: 300px;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (document.body.contains(notification)) {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return '✅';
        case 'error': return '❌';
        case 'warning': return '⚠️';
        default: return 'ℹ️';
    }
}

function getNotificationColor(type) {
    switch (type) {
        case 'success': return '#10B981';
        case 'error': return '#EF4444';
        case 'warning': return '#F59E0B';
        default: return '#3B82F6';
    }
}

// Modal creator utility
function createInfoModal(title, content, buttons) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    
    const buttonHTML = buttons.map(btn => 
        `<button class="btn ${btn.primary ? 'btn-primary' : 'btn-outline'}" 
                 onclick="${btn.action ? btn.action.name + '(); this.closest(\'.modal\').remove();' : 'this.closest(\'.modal\').remove();'}"
                 style="margin: 0.25rem;">
            ${btn.text}
         </button>`
    ).join('');
    
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body">
                <p style="white-space: pre-line; line-height: 1.6;">${content}</p>
                <div style="margin-top: 1.5rem; display: flex; flex-wrap: wrap; gap: 0.5rem; justify-content: center;">
                    ${buttonHTML}
                </div>
            </div>
        </div>
    `;
    
    return modal;
}

// Analytics tracking (placeholder)
function trackEvent(eventName, properties = {}) {
    console.log('Analytics Event:', eventName, properties);
    // In production, integrate with Google Analytics, Mixpanel, etc.
}

// Performance monitoring
function measurePageLoad() {
    window.addEventListener('load', () => {
        const loadTime = performance.now();
        trackEvent('page_load', { load_time: Math.round(loadTime) });
    });
}

// Initialize performance monitoring
measurePageLoad();

// Service Worker messaging
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type === 'CACHE_UPDATED') {
            showNotification('La aplicación ha sido actualizada', 'success');
        }
    });
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: white;
        font-size: 1.25rem;
        cursor: pointer;
        opacity: 0.8;
        margin-left: auto;
    }
    
    .notification-close:hover {
        opacity: 1;
    }
    
    .mobile-menu-btn.active span:nth-child(1) {
        transform: rotate(45deg) translate(5px, 5px);
    }
    
    .mobile-menu-btn.active span:nth-child(2) {
        opacity: 0;
    }
    
    .mobile-menu-btn.active span:nth-child(3) {
        transform: rotate(-45deg) translate(7px, -6px);
    }
`;
document.head.appendChild(style);

// Export functions for global access
window.ServiMap = {
    showInstallPrompt,
    closeInstallModal,
    installPWA,
    toggleMobileMenu,
    scrollToServices,
    downloadAndroid,
    downloadiOS,
    showWebAppInfo,
    showPrivacyPolicy,
    showTermsOfService,
    showCookiePolicy,
    showNotification,
    trackEvent
};